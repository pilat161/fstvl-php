<?php

$telegram_id = "6777935131";
$id_bot      = "7909861355:AAEqeIiN7AKwGApduNxbHjG8ZrUvmqfPbBs";
?>
